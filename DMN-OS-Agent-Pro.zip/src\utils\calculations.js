export const won = (value = 0) => `${Math.round(Number(value || 0)).toLocaleString('ko-KR')}원`;
export const percent = (value = 0) => `${(Number(value || 0) * 100).toFixed(1)}%`;
export const monthKey = (date = new Date().toISOString().slice(0, 10)) => date.slice(0, 7);
export function dashboard(data) {
  const a = data.assets; const totalAssets = +a.cash + +a.stocks + +a.crypto; const totalDebt = +a.debt + +a.cardDue;
  const currentMonth = monthKey(); const tx = data.transactions.filter(x => monthKey(x.date) === currentMonth);
  const income = tx.filter(x => x.type === 'income').reduce((s, x) => s + +x.amount, 0); const expense = tx.filter(x => x.type === 'expense').reduce((s, x) => s + +x.amount, 0);
  const emotionScore = Math.round(Object.values(data.emotion).reduce((s, v) => s + +v, 0) / 60 * 100);
  return { totalAssets, totalDebt, netWorth: totalAssets - totalDebt, cashRatio: totalAssets ? +a.cash / totalAssets : 0, stockRatio: totalAssets ? +a.stocks / totalAssets : 0, debtRatio: totalAssets ? totalDebt / totalAssets : 0, goalRatio: a.targetNetWorth ? (totalAssets - totalDebt) / +a.targetNetWorth : 0, income, expense, living: income - expense, emotionScore, entry: emotionScore >= 70 ? '신규 진입 금지' : emotionScore >= 40 ? '신규 진입 주의' : '신규 진입 가능' };
}
export function positionStats(p) { const value = (+p.currentPrice || 0) * (+p.quantity || 0); const cost = (+p.entryPrice || 0) * (+p.quantity || 0); return { value, pnl: value - cost, roi: cost ? (value - cost) / cost : 0 }; }
