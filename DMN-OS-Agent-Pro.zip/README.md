# DMN OS Agent Pro

개인 자산·생활 흐름·투자 포지션·매매일지·감정 리스크를 한 기기에서 관리하는 Android용 Expo 앱입니다. 모든 데이터는 기기에 저장되며, JSON 백업/복원이 실제로 동작합니다.

## 생성 파일과 역할

- `index.js`, `App.js`: 앱 시작점과 하단 6개 탭
- `src/screens/`: 각 기능 화면
- `src/components/`: 재사용 카드, 버튼, 입력창
- `src/store/defaultData.js`: 첫 실행 기본 자산 데이터
- `src/store/storage.js`: 기기 저장소(AsyncStorage)
- `src/utils/calculations.js`: 자산·감정·포지션 자동 계산
- `src/utils/backup.js`: JSON 백업과 복원
- `src/utils/excelImportPlaceholder.js`: 다음 버전 Excel Import 확장 자리
- `app.json`: Android 패키지명 `com.dmn.osagentpro`
- `eas.json`: preview APK 빌드 설정

## 컴퓨터에서 실행

```bash
npm install
npx expo start
```

화면의 QR을 Expo Go로 열어 중간 테스트할 수 있습니다. **설치용 APK는 아래 EAS 빌드로 만듭니다.**

## 설치 가능한 APK 만들기

1. [Expo 회원가입](https://expo.dev/signup)을 합니다.
2. 터미널에서 아래를 차례로 실행합니다.

```bash
npm install -g eas-cli
eas login
eas build:configure
eas build -p android --profile preview
```

3. `eas build:configure`가 `app.json`의 `projectId`를 자동으로 실제 값으로 바꾸도록 허용합니다.
4. 빌드가 끝나면 표시되는 Expo 링크를 휴대폰에서 열고 APK를 내려받습니다.
5. Android의 “알 수 없는 앱 설치” 허용을 켠 뒤 다운로드한 APK를 눌러 설치합니다.

## 모바일만으로 하는 가장 쉬운 방법

휴대폰에서 GitHub Codespaces 또는 Expo Snack이 아니라 **GitHub Codespaces(또는 Replit의 Node 프로젝트)** 를 열어 이 폴더를 업로드/압축 해제하세요. 그 안의 터미널에서 위 EAS 명령을 실행하면 됩니다. EAS 빌드는 Expo 서버에서 진행되어 휴대폰이 계속 켜져 있을 필요가 없습니다. 완료 화면의 APK 링크를 휴대폰에서 열어 설치하세요.

## 자주 만나는 문제

- `npm install` 오류: Node.js LTS(20 이상)에서 다시 시도하세요.
- `eas login` 오류: Expo 가입 이메일과 비밀번호를 다시 확인하세요.
- APK가 아닌 `.aab`가 생성됨: 반드시 `--profile preview`를 사용하세요.
- 설치 차단: Android 설정에서 해당 브라우저/파일 앱의 “알 수 없는 앱 설치”를 허용하세요.
- 백업 파일을 못 찾음: 백업 후 공유 창에서 Google Drive 또는 Files 앱을 직접 선택하세요.

## 수정하기 좋은 파일

- 색상/첫 화면: `App.js`, `src/screens/HomeScreen.js`
- 첫 자산 숫자: `src/store/defaultData.js`
- 계산식: `src/utils/calculations.js`
- Excel Import 확장: `src/utils/excelImportPlaceholder.js`
