// 다음 버전에서 xlsx 라이브러리로 CFO Master 시트를 매핑할 자리입니다.
export function getExcelImportMessage() { return 'CFO Master 엑셀 자동 가져오기는 다음 버전에서 지원됩니다.\n현재는 JSON 백업/복원을 사용해주세요.'; }
export async function importCfoMasterPlaceholder() { return { supported: false, message: getExcelImportMessage() }; }
