export default {
  assets: { cash: 2459436, stocks: 19328261, crypto: 0, debt: 5000000, cardDue: 0, targetNetWorth: 30000000 },
  transactions: [],
  categories: ['식비', '교통', '생활비', '구독', '데이트', '기타'],
  positions: [],
  trades: [],
  emotion: { anxiety: 0, impatience: 0, fomo: 0, revenge: 0, overconfidence: 0, fatigue: 0 }
};
