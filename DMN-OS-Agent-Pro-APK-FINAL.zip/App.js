import React, { useEffect, useState } from 'react';
import { ActivityIndicator, StatusBar, StyleSheet, View } from 'react-native';
import { NavigationContainer, DarkTheme } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { SafeAreaProvider, useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { loadData, saveData } from './src/store/storage';
import defaultData from './src/store/defaultData';
import HomeScreen from './src/screens/HomeScreen';
import AssetsScreen from './src/screens/AssetsScreen';
import PositionsScreen from './src/screens/PositionsScreen';
import TradeJournalScreen from './src/screens/TradeJournalScreen';
import EmotionCheckScreen from './src/screens/EmotionCheckScreen';
import SettingsScreen from './src/screens/SettingsScreen';

const Tab = createBottomTabNavigator();
const colors = { bg: '#0B1220', card: '#121A2A', mint: '#3DD9C5', blue: '#4FA3FF', text: '#F5F7FA' };
const icons = { '홈': 'home', '자산': 'wallet', '투자': 'trending-up', '일지': 'book', '감정': 'heart', '설정': 'settings' };

export default function App() {
  const [data, setData] = useState(null);
  useEffect(() => { loadData().then(setData); }, []);
  const update = async (next) => { setData(next); await saveData(next); };
  if (!data) return <View style={styles.loading}><ActivityIndicator size="large" color={colors.mint} /></View>;
  const shared = { data, update };
  return <SafeAreaProvider><NavigationContainer theme={{ ...DarkTheme, colors: { ...DarkTheme.colors, background: colors.bg, card: colors.card, text: colors.text, primary: colors.mint } }}>
    <StatusBar barStyle="light-content" />
    <MainTabs data={data} update={update} setData={setData} />
  </NavigationContainer></SafeAreaProvider>;
}
function MainTabs({ data, update, setData }) {
  const insets = useSafeAreaInsets(); const shared = { data, update };
  return <Tab.Navigator screenOptions={({ route }) => ({ headerShown: false, tabBarStyle: [styles.tab, { height: 64 + insets.bottom, paddingBottom: Math.max(insets.bottom, 8) }], tabBarActiveTintColor: colors.mint, tabBarInactiveTintColor: '#718096', tabBarIcon: ({ color, size }) => <Ionicons name={icons[route.name]} color={color} size={size} /> })}>
      <Tab.Screen name="홈">{() => <HomeScreen {...shared} />}</Tab.Screen>
      <Tab.Screen name="자산">{() => <AssetsScreen {...shared} />}</Tab.Screen>
      <Tab.Screen name="투자">{() => <PositionsScreen {...shared} />}</Tab.Screen>
      <Tab.Screen name="일지">{() => <TradeJournalScreen {...shared} />}</Tab.Screen>
      <Tab.Screen name="감정">{() => <EmotionCheckScreen {...shared} />}</Tab.Screen>
      <Tab.Screen name="설정">{() => <SettingsScreen {...shared} setData={setData} defaultData={defaultData} />}</Tab.Screen>
    </Tab.Navigator>
  ;
}
const styles = StyleSheet.create({ loading: { flex: 1, backgroundColor: colors.bg, alignItems: 'center', justifyContent: 'center' }, tab: { backgroundColor: '#101827', borderTopColor: '#1E293B' } });
