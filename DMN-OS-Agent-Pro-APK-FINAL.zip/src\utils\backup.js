import { File, Paths } from 'expo-file-system';
import * as Sharing from 'expo-sharing';
import * as DocumentPicker from 'expo-document-picker';
export async function exportBackup(data) { const file = new File(Paths.document, `DMN-OS-backup-${new Date().toISOString().slice(0, 10)}.json`); file.write(JSON.stringify(data, null, 2)); if (await Sharing.isAvailableAsync()) await Sharing.shareAsync(file.uri, { mimeType: 'application/json', dialogTitle: 'DMN OS 백업 저장' }); return file.uri; }
export async function importBackup() { const result = await DocumentPicker.getDocumentAsync({ type: 'application/json', copyToCacheDirectory: true }); if (result.canceled) return null; const raw = await new File(result.assets[0].uri).text(); const parsed = JSON.parse(raw); if (!parsed.assets || !parsed.emotion) throw new Error('DMN OS 백업 파일이 아닙니다.'); return parsed; }
