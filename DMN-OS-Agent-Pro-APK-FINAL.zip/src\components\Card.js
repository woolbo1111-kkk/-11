import React from 'react'; import { StyleSheet, View } from 'react-native';
export default function Card({ children, style }) { return <View style={[styles.card, style]}>{children}</View>; }
const styles = StyleSheet.create({ card: { backgroundColor: '#121A2A', borderRadius: 18, padding: 16, marginBottom: 12, borderWidth: 1, borderColor: '#1E2A3E' } });
