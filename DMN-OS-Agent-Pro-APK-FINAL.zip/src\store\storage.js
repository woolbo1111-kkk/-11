import AsyncStorage from '@react-native-async-storage/async-storage';
import defaultData from './defaultData';
const KEY = '@dmn_os_agent_pro';
export async function loadData() { try { const raw = await AsyncStorage.getItem(KEY); return raw ? { ...defaultData, ...JSON.parse(raw) } : defaultData; } catch { return defaultData; } }
export async function saveData(data) { await AsyncStorage.setItem(KEY, JSON.stringify(data)); }
export async function clearData() { await AsyncStorage.removeItem(KEY); }
