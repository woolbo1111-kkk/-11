import * as DocumentPicker from 'expo-document-picker';
import { File } from 'expo-file-system';
import * as XLSX from 'xlsx';

const money = (value) => {
  if (typeof value === 'number') return Number.isFinite(value) ? value : 0;
  const parsed = Number(String(value ?? '').replace(/[^0-9.-]/g, ''));
  return Number.isFinite(parsed) ? parsed : 0;
};
const rows = (workbook, name) => XLSX.utils.sheet_to_json(workbook.Sheets[name], { header: 1, defval: '', raw: true });
const findValue = (sheetRows, label) => {
  const row = sheetRows.find((item) => String(item[0]).trim() === label);
  return row ? money(row[1]) : null;
};
const marketType = (market) => String(market).includes('코인') ? '코인' : '주식';
const formatDate = (value) => value instanceof Date ? value.toISOString().slice(0, 10) : String(value).slice(0, 10);

function readLatestPositions(sheetRows) {
  const marker = sheetRows.findIndex((row) => String(row[0]).includes('[새 포트폴리오]'));
  if (marker < 0) throw new Error('03_포트폴리오 시트에서 [새 포트폴리오] 구역을 찾지 못했습니다.');
  const header = sheetRows.findIndex((row, index) => index > marker && row[2] === '종목');
  if (header < 0) throw new Error('새 포트폴리오의 열 제목을 찾지 못했습니다.');
  const positions = [];
  for (let index = header + 1; index < sheetRows.length; index += 1) {
    const row = sheetRows[index];
    if (!row[2]) break;
    const name = String(row[2]).trim();
    const quantity = money(row[3]); const entryPrice = money(row[4]); const currentPrice = money(row[5]);
    if (!name || quantity <= 0) continue;
    positions.push({
      id: `excel-position-${Date.now()}-${index}`,
      name,
      market: marketType(row[1]),
      direction: '보유',
      entryPrice,
      currentPrice,
      quantity,
      stopLoss: 0,
      targetPrice: 0,
      memo: [row[0] ? `계좌 ${row[0]}` : '', row[11], row[12]].filter(Boolean).join(' · ')
    });
  }
  if (!positions.length) throw new Error('가져올 최신 포지션이 없습니다.');
  return positions;
}

function readTradeLogs(sheetRows) {
  const header = sheetRows.findIndex((row) => row[0] === '날짜' && row[2] === '종목/섹터');
  if (header < 0) return [];
  const output = [];
  for (let index = header + 1; index < sheetRows.length; index += 1) {
    const row = sheetRows[index];
    if (!row[0] || !row[2]) break;
    output.push({ id: `excel-trade-${Date.now()}-${index}`, date: formatDate(row[0]), symbol: String(row[2]), action: String(row[3] || row[1] || '관망'), amount: 0, reason: String(row[4] || ''), stopLoss: '', result: String(row[7] || ''), lesson: [row[5], row[6], row[8]].filter(Boolean).join(' / ') });
  }
  return output;
}

export async function importCfoMasterExcel(currentData) {
  const result = await DocumentPicker.getDocumentAsync({ type: ['application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'application/vnd.ms-excel'], copyToCacheDirectory: true });
  if (result.canceled) return null;
  const file = new File(result.assets[0].uri);
  const workbook = XLSX.read(await file.base64(), { type: 'base64', cellDates: true });
  for (const name of ['02_기준데이터', '03_포트폴리오']) if (!workbook.Sheets[name]) throw new Error(`필수 시트 '${name}'가 없습니다.`);
  const baseline = rows(workbook, '02_기준데이터'); const positions = readLatestPositions(rows(workbook, '03_포트폴리오'));
  const cash = findValue(baseline, '현금성 자산'); const other = findValue(baseline, '기타자산'); const debt = findValue(baseline, '신용대출 잔액'); const targetNetWorth = findValue(baseline, '1년 순자산 목표');
  const stocks = positions.reduce((sum, position) => sum + position.currentPrice * position.quantity, 0);
  const trades = workbook.Sheets['08_투자행동로그'] ? readTradeLogs(rows(workbook, '08_투자행동로그')) : [];
  const nextData = { ...currentData, assets: { ...currentData.assets, ...(cash !== null ? { cash } : {}), ...(other !== null ? { other } : {}), ...(debt !== null ? { debt } : {}), ...(targetNetWorth !== null ? { targetNetWorth } : {}), stocks }, positions, trades: trades.length ? trades : currentData.trades };
  return { data: nextData, summary: { positions: positions.length, trades: trades.length, cash: nextData.assets.cash, other: nextData.assets.other || 0, stocks, debt: nextData.assets.debt } };
}
